export class Seat {
  public seatId: number;
  public seatNumber: string;
  public type: string;
  public price: number;
  public status: string;
}
